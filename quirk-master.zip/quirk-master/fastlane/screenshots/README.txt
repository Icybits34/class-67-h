Put all screenshots you want to use inside the folder of its language (e.g. en-US).
The device type will automatically be recognized using the image resolution. Apple TV screenshots
should be stored in a subdirectory named appleTV with language folders inside of it. iMessage
screenshots, like Apple TV screenshots, should also be stored in a subdirectory named iMessage
with language folders inside of it.

The screenshots can be named whatever you want, but keep in mind they are sorted alphabetically.
